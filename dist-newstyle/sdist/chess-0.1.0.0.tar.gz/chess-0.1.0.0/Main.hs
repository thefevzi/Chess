import ChessBoard
import Color
import Position
import Data.Char (ord)
import Data.Maybe (isJust)

-- Function to parse user input into a move
parseMove :: String -> Maybe (Position, Position)
parseMove [f1, r1, f2, r2]
    | all (`elem` ['a'..'h']) [f1, f2] && all (`elem` ['1'..'8']) [r1, r2] =
        Just (Position (ord r1 - ord '1') (ord f1 - ord 'a'),
              Position (ord r2 - ord '1') (ord f2 - ord 'a'))
    | otherwise = Nothing
parseMove _ = Nothing

-- Function to check if a move is valid
isValidMove :: ChessBoard -> Position -> Position -> Bool
isValidMove board from to = isJust (at board from) && (toIndex from /= toIndex to)

-- Function to print the board
printBoard :: ChessBoard -> IO ()
printBoard = putStrLn . show

-- Game loop
gameLoop :: ChessBoard -> IO ()
gameLoop board = do
    printBoard board
    putStrLn $ "Next move: " ++ show (nextMove board)
    putStrLn "Enter your move (e.g., d2d4):"
    input <- getLine
    case parseMove input of
        Nothing -> do
            putStrLn "Invalid move format."
            gameLoop board
        Just (from, to) ->
            if isValidMove board from to
            then gameLoop (movePiece (switch board) from to)
            else do
                putStrLn "Invalid move."
                gameLoop board

main :: IO ()
main = do
    putStrLn "Welcome to Haskell Chess!"
    gameLoop initialPosition
